/*! For license information please see bundle.js.LICENSE.txt */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;(()=>{"use strict";var e={};(()=>{var t=e;Object.defineProperty(t,"__esModule",{value:!0}),t.JustaLabelControl=void 0;var a=function(){function e(){}return e.prototype.init=function(e,t,a,r){this._divElement=r,null!=e.parameters.labeltext&&(this._divElement.innerHTML=e.parameters.labeltext.raw?e.parameters.labeltext.raw:""),null!=e.parameters.styleparam&&this._divElement.setAttribute("style",e.parameters.styleparam.raw||"")},e.prototype.updateView=function(e){null!=e.parameters.labeltext&&(this._divElement.innerHTML=e.parameters.labeltext.raw?e.parameters.labeltext.raw:""),null!=e.parameters.styleparam&&this._divElement.setAttribute("style",e.parameters.styleparam.raw||"")},e.prototype.getOutputs=function(){return{}},e.prototype.destroy=function(){},e}();t.JustaLabelControl=a})(),pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad=e})();
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Contoso.JustaLabelControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.JustaLabelControl);
} else {
	var Contoso = Contoso || {};
	Contoso.JustaLabelControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.JustaLabelControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}